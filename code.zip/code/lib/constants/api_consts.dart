String BASE_URL = "https://api.openai.com/v1";
String API_KEY = "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";